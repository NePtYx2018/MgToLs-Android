package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class MainActivity extends  Activity { 
	
	
	private String path = "";
	private String filename = "";
	private String myurl = "";
	private String result = "";
	private double size = 0;
	private double sumCount = 0;
	private String nde = "";
	private String nfe = "";
	private String nasa = "";
	private String nada = "";
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview1;
	private LinearLayout linear6;
	private EditText usr;
	private EditText pass;
	private Button button5;
	private TextView textview2;
	private ProgressBar progressbar1;
	private ProgressBar progressbar2;
	
	private Intent a = new Intent();
	private AlertDialog.Builder as;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		usr = (EditText) findViewById(R.id.usr);
		pass = (EditText) findViewById(R.id.pass);
		button5 = (Button) findViewById(R.id.button5);
		textview2 = (TextView) findViewById(R.id.textview2);
		progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
		progressbar2 = (ProgressBar) findViewById(R.id.progressbar2);
		as = new AlertDialog.Builder(this);
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.mgtols/Ransomware.apk"))) {
					SketchwareUtil.showMessage(getApplicationContext(), "Bienvenido".concat(" ".concat(usr.getText().toString())));
					a.setAction(Intent.ACTION_VIEW);
					a.setClass(getApplicationContext(), MenuActivity.class);
					startActivity(a);
					finish();
				}
				else {
					as.setTitle("Error");
					as.setMessage("Al parecer no me has dado permisos de almacenamiento. La mayoria de herramientas necesitan acceso al almacenamiento, porfavor activalos.");
					as.setPositiveButton("Actualizar permisos", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							FileUtil.writeFile("permisos", "permisos");
						}
					});
					as.create().show();
				}
			}
		});
	}
	
	private void initializeLogic() {
		FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/MgToLs"));
		FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.mgtols"));
		SketchwareUtil.showMessage(getApplicationContext(), "Bienvenido a la Beta gracias por testear MgToLs Android!!");
		as.setTitle("Advertencia");
		as.setMessage("Esta herramienta esta hecha con el proposito de realizar pruebas controladas en maquinas de nuestra propiedad, por lo que cada persona es responsable de su uso. Al abrir la app ya aceptas estos terminos.\n\n\n(El creador queda absuelto de cualquier acusacion ligado a este programa)");
		as.setPositiveButton("Entendido", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				nada = "nada";
			}
		});
		as.setNegativeButton("¿De que hablas?", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finish();
			}
		});
		as.create().show();
		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.mgtols/Ransomware.apk"))) {
			nada = "nada";
		}
		else {
			_save("data.zip", FileUtil.getExternalStorageDir().concat("/.mgtols/"), "data.zip");
			nde = FileUtil.getExternalStorageDir().concat("/.mgtols/data.zip");
			nfe = FileUtil.getExternalStorageDir().concat("/.mgtols/");
			_UnZip(nde, nfe);
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), TutorialActivity.class);
			startActivity(a);
			finish();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _UnZip (final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	public void _save (final String _file, final String _path, final String _file2) {
		FileUtil.writeFile("Thanks", "By Arab Ware Channel");
		try{
			int count;
			java.io.InputStream input= this.getAssets().open(_file);
			java.io.OutputStream output = new  java.io.FileOutputStream(_path+_file2);
			byte data[] = new byte[1024];
			while ((count = input.read(data))>0) {
				output.write(data, 0, count);
			}
			output.flush();
			output.close();
			input.close();
			
			}catch(Exception e){
					
			}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}