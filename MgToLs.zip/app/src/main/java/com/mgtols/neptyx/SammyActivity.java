package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class SammyActivity extends  Activity { 
	
	
	private boolean off = false;
	private String ksk = "";
	private String xks = "";
	private String trans = "";
	private double count = 0;
	private String traps = "";
	private double kalista = 0;
	private String juan = "";
	private String comandos = "";
	private String juin = "";
	
	private ArrayList<String> jijis = new ArrayList<>();
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private EditText edittext1;
	private EditText edittext2;
	private EditText edittext3;
	private Button button1;
	private TextView textview1;
	private WebView webview1;
	
	private Intent a = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sammy);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		edittext3 = (EditText) findViewById(R.id.edittext3);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), MenuActivity.class);
				startActivity(a);
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				juin = FileUtil.readFile(edittext1.getText().toString()).replace(" ", "\n");
				FileUtil.writeFile(edittext1.getText().toString(), juin);
				if (edittext1.getText().toString().equals("") || edittext2.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Rellena todos los campos");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Decifrando espere");
					kalista = edittext2.getText().toString().trim().length();
					if (kalista == 32) {
						edittext3.setText("md5sum");
					}
					if (kalista == 40) {
						edittext3.setText("sha1sum");
					}
					if (kalista == 56) {
						edittext3.setText("sha224sum");
					}
					if (kalista == 64) {
						edittext3.setText("sha256sum");
					}
					if (kalista == 96) {
						edittext3.setText("sha384sum");
					}
					if (kalista == 128) {
						edittext3.setText("sha512sum");
					}
					off = true;
					ksk = "valor=$(echo \"p\")\nline=$(sed -n uwu$valor filename)\nlines=$(echo \"$line\" | metodo)\n\nif [ \"$lines\" = \"hashname\" ]; then\necho \"COINCIDENCIA ENCONTRADA: LLAVE: $line HASH: $lines\" > filepath\nelse\necho \"ERROR: LLAVE: $line HASH: $lines\"\nfi".replace("filename", edittext1.getText().toString());
					juan = ksk.replace("metodo", edittext3.getText().toString());
					xks = juan.replace("hashname", edittext2.getText().toString().concat("  -"));
					trans = xks.replace("filepath", FileUtil.getExternalStorageDir().concat("/.mgtols/md5.txt"));
					while(off) {
							if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.mgtols/md5.txt"))) {
									textview1.setText("HASH ENCONTRADO: ".concat(String.valueOf((long)(count))));
									webview1.loadUrl("file://".concat(FileUtil.getExternalStorageDir().concat("/.mgtols/md5.txt")));
									off = false;
							}
							else {
									traps = trans.replace("uwu", String.valueOf((long)(count)));
									_shell(traps);
									count++;
									textview1.setText("DECIFRANDO HASH: ".concat(String.valueOf((long)(count))));
							}
					}
				}
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
	}
	
	private void initializeLogic() {
		FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/.mgtols/md5.txt"));
		count = 1;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _shell (final String _cmd) {
		
		String[] cmdline = { "sh", "-c", (_cmd) }; 
		try {
				Runtime.getRuntime().exec(cmdline);
		} catch (Exception s) {
				finishAffinity();
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}