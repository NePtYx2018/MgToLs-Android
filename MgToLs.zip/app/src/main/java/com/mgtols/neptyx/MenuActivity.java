package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.Button;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class MenuActivity extends  Activity { 
	
	
	private String des = "";
	private String url = "";
	private String path = "";
	private String filename = "";
	private String var = "";
	private String var1 = "";
	
	private ArrayList<String> lista = new ArrayList<>();
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private AutoCompleteTextView menu;
	private LinearLayout linear5;
	private Button button1;
	private Button button5;
	private LinearLayout linear3;
	private Button button2;
	private WebView webview1;
	private LinearLayout linear6;
	private Button button3;
	private LinearLayout linear7;
	private Button button4;
	private TextView textview1;
	
	private Intent a = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.menu);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		menu = (AutoCompleteTextView) findViewById(R.id.menu);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		button1 = (Button) findViewById(R.id.button1);
		button5 = (Button) findViewById(R.id.button5);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		button2 = (Button) findViewById(R.id.button2);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		button3 = (Button) findViewById(R.id.button3);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		button4 = (Button) findViewById(R.id.button4);
		textview1 = (TextView) findViewById(R.id.textview1);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_todo();
				if (menu.getText().toString().equals("Userdox")) {
					a.setAction(Intent.ACTION_VIEW);
					a.setClass(getApplicationContext(), UserdoxActivity.class);
					startActivity(a);
					finish();
				}
				if (menu.getText().toString().equals("ZFor")) {
					a.setAction(Intent.ACTION_VIEW);
					a.setClass(getApplicationContext(), ZforActivity.class);
					startActivity(a);
					finish();
				}
				if (menu.getText().toString().equals("Dixmak")) {
					a.setAction(Intent.ACTION_VIEW);
					a.setClass(getApplicationContext(), DixmakActivity.class);
					startActivity(a);
					finish();
				}
				if (menu.getText().toString().equals("Sammy")) {
					a.setAction(Intent.ACTION_VIEW);
					a.setClass(getApplicationContext(), SammyActivity.class);
					startActivity(a);
					finish();
				}
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), OtrosActivity.class);
				startActivity(a);
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), AyudaActivity.class);
				startActivity(a);
				finish();
			}
		});
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/MgToLs/Complementos"));
				var = FileUtil.getExternalStorageDir().concat("/.mgtols/");
				var1 = FileUtil.getExternalStorageDir().concat("/MgToLs/Complementos/");
				FileUtil.copyFile(var.concat("sitios.txt"), var1.concat("sitios.txt"));
				FileUtil.copyFile(var.concat("md5.apk"), var1.concat("md5.apk"));
				FileUtil.copyFile(var.concat("apkeditor.apk"), var1.concat("apkeditor.apk"));
				SketchwareUtil.showMessage(getApplicationContext(), "Archivos guardados en ".concat(var1));
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), LicenciaActivity.class);
				startActivity(a);
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		_uwu();
		menu.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, lista));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _UnZip (final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	public void _uwu () {
		lista.clear();
		lista.add("Scaf");
		lista.add("IpLocate");
		lista.add("VirusCreator");
		lista.add("Geonumb");
		lista.add("GmailSpammer");
		lista.add("Stalk");
		lista.add("ShortUrl");
		lista.add("WifiCrack");
		lista.add("Ados");
		lista.add("Myip");
		lista.add("Mac0s");
		lista.add("KeyMaker");
		lista.add("AmWare");
		lista.add("Spamaker");
		lista.add("Dogle");
		lista.add("Doxrut");
		lista.add("Encry");
		lista.add("HtmlView");
		lista.add("Scama");
		lista.add("DirectLnk");
		lista.add("DeepClean");
		lista.add("Naser");
		lista.add("Dolds");
		lista.add("Domain");
		lista.add("IMEGet");
		lista.add("Userdox");
		lista.add("ZFor");
		lista.add("Dixmak");
		lista.add("Sammy");
	}
	
	
	public void _todo () {
		if (menu.getText().toString().equals("Scaf")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), ScafActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("GmailSpammer")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), GmailspammerActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("IpLocate")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), IplocateActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Geonumb")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), GeonumbActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("VirusCreator")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), ViruscActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Stalk")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), StalkActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("ShortUrl")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), ShorturlActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("WifiCrack")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), WificrackActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Ados")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), AdosActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Myip")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), MyipActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Mac0s")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), MacosActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("KeyMaker")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), KeymakerActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("AmWare")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), AmwareActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Spamaker")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), SpamakerActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Encry")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), EncryActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Doxrut")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), DoxrutActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Dogle")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), DogleActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("HtmlView")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), HtmlviewActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Scama")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), ScamaActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("DirectLnk")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), DirectlnkActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("DeepClean")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), DeepcleanActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Naser")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), NaserActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Dolds")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), DoldsActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("Domain")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), DomainActivity.class);
			startActivity(a);
			finish();
		}
		if (menu.getText().toString().equals("IMEGet")) {
			a.setAction(Intent.ACTION_VIEW);
			a.setClass(getApplicationContext(), ImegetActivity.class);
			startActivity(a);
			finish();
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}