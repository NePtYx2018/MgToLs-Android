package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class AyudaActivity extends  Activity { 
	
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private ScrollView vscroll1;
	private TextView textview1;
	
	private Intent a = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.ayuda);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		textview1 = (TextView) findViewById(R.id.textview1);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), MenuActivity.class);
				startActivity(a);
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		textview1.setText("Herramientas incluidas en MgToLs para android:\n\n-GmailSpammer: Ataca con correos de spam.\n\n-Scaf: Scam fisico.\n\n-Myip: Cual es mi ip y su informacion.\n\n-IpLocate: Localiza la ip dando detalles como el proveedor de internet, y su comuna.\n\n-Scama: Creador de scam.\n\n-HtmlView: Ver codigo fuente de paginas web.\n\n-Dogle: Busca coincidencias exactas en paginas indexadas.\n\n-Doxrut: Doxeo mediante rutificador. Solo para chile.\n\n-Geonumb: Mediante triangulacion localiza el numero y te da a conocer su compañia.\n\n-VirusCreator: Crea tanto Malware, Ransomware, y SpyWare desde android.\n\n-Stalk: Herramienta basada en FBI de termux la cual recopila informacion de los perfiles con su id.\n\n-ShortUrl: Es un camuflador de url mediante un @ que se usa para redireccionar a otra pagina.\n\n-WifiCrack: Herramienta que te permite buscar las contraseñas predeterminadas de los routers.\n\n-Ados: Herramienta que realiza un DOS abriendo muchas veces la pagina seleccionada.\n\n-Mac0s: Averiguar quien es el fabricante de la mac.\n\n-KeyMaker: Herramienta para crear keyloggers en lenguaje python.\n\n-AmWare: Antivirus para android basado en la comparacion de hash maliciosos.\n\n-Spamaker: Herramienta para crear lag para WhatsApp.\n\n-Encry: Herramienta para crear Ransomware para Windows.\n\n-DirectLnk: Crea accesos directos infectados.\n\n-DeepClean: Limpia la memoria del celular.\n\n-Naser: Buscador de dnis en latinoamerica.\n\n-Dolds: Atacar ip mediante protocolo icmp.\n\n-Domain: Recolecta informacion de dominios mediante WhoIs.\n\n-IMEGet: Obtiene la IMEI que llega mediante un correo electronico.\n\n-Userdox: Doxing de nombres de usuarios en internet.\n\n-ZFor: Busca invitaciones de zoom recurrentes.\n\n-Dixmak: Crea diccionarios a partir de datos proporcionados.\n\n-Sammy: Decifra hash en md5, sha1, sha256, etc.\n\nEsta herramienta esta hecha con fines educativos e informativos no me hago responsable de su mal uso.");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}