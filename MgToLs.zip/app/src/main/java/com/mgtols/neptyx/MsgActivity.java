package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.webkit.WebView;
import android.webkit.WebSettings;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.webkit.WebViewClient;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class MsgActivity extends  Activity { 
	
	private Timer _timer = new Timer();
	
	private String name = "";
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private EditText usuario;
	private Button buscar;
	private WebView curl;
	private WebView mensajes;
	private EditText mensajeaenviar;
	private Button enviarxd;
	private Button update;
	
	private TimerTask laps;
	private Intent a = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.msg);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		usuario = (EditText) findViewById(R.id.usuario);
		buscar = (Button) findViewById(R.id.buscar);
		curl = (WebView) findViewById(R.id.curl);
		curl.getSettings().setJavaScriptEnabled(true);
		curl.getSettings().setSupportZoom(true);
		mensajes = (WebView) findViewById(R.id.mensajes);
		mensajes.getSettings().setJavaScriptEnabled(true);
		mensajes.getSettings().setSupportZoom(true);
		mensajeaenviar = (EditText) findViewById(R.id.mensajeaenviar);
		enviarxd = (Button) findViewById(R.id.enviarxd);
		update = (Button) findViewById(R.id.update);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), OtrosActivity.class);
				startActivity(a);
				finish();
			}
		});
		
		buscar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (usuario.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Introduce un nombre valido!!");
				}
				else {
					name = usuario.getText().toString().concat(": ");
					buscar.setVisibility(View.GONE);
					usuario.setVisibility(View.GONE);
					mensajes.setVisibility(View.VISIBLE);
					mensajeaenviar.setVisibility(View.VISIBLE);
					enviarxd.setVisibility(View.VISIBLE);
					update.setVisibility(View.VISIBLE);
				}
			}
		});
		
		curl.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		mensajes.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		enviarxd.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (mensajeaenviar.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Introduce un mensaje valido!!");
				}
				else {
					curl.loadUrl("https://whatsapp.webcindario.com/log.php?nombre=".concat(name.concat(mensajeaenviar.getText().toString())));
					mensajeaenviar.setText("");
				}
			}
		});
		
		update.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mensajes.clearCache(true);
				mensajes.loadUrl("https://whatsapp.webcindario.com/chat.txt");
			}
		});
	}
	
	private void initializeLogic() {
		mensajes.setVisibility(View.GONE);
		mensajeaenviar.setVisibility(View.GONE);
		enviarxd.setVisibility(View.GONE);
		curl.setVisibility(View.GONE);
		update.setVisibility(View.GONE);
		mensajes.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
		mensajes.clearCache(true);
		mensajes.loadUrl("https://whatsapp.webcindario.com/chat.txt");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}