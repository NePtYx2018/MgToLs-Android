package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import android.widget.AdapterView;
import android.content.ClipData;
import android.content.ClipboardManager;
import com.google.gson.Gson;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class ZforActivity extends  Activity { 
	
	private Timer _timer = new Timer();
	
	private String base = "";
	private double a = 0;
	private double b = 0;
	private double c = 0;
	private double d = 0;
	private double e = 0;
	private double f = 0;
	private double g = 0;
	private double h = 0;
	private double i = 0;
	private double j = 0;
	private double k = 0;
	private double todos = 0;
	private double contador = 0;
	private HashMap<String, Object> headers = new HashMap<>();
	private HashMap<String, Object> response = new HashMap<>();
	
	private ArrayList<String> enlaces = new ArrayList<>();
	private ArrayList<String> terminados = new ArrayList<>();
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private LinearLayout linear2;
	private EditText edittext1;
	private Button button1;
	private Button button2;
	private Spinner spinner1;
	private ScrollView vscroll1;
	private TextView textview1;
	
	private Intent axd = new Intent();
	private TimerTask stop;
	private RequestNetwork rm;
	private RequestNetwork.RequestListener _rm_request_listener;
	private RequestNetwork test;
	private RequestNetwork.RequestListener _test_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.zfor);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		button1 = (Button) findViewById(R.id.button1);
		button2 = (Button) findViewById(R.id.button2);
		spinner1 = (Spinner) findViewById(R.id.spinner1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		textview1 = (TextView) findViewById(R.id.textview1);
		rm = new RequestNetwork(this);
		test = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				axd.setAction(Intent.ACTION_VIEW);
				axd.setClass(getApplicationContext(), MenuActivity.class);
				startActivity(axd);
				finish();
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("") || edittext1.getText().toString().equals("1")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Rellena todos los campos");
				}
				else {
					base = "https://us02web.zoom.us/j/";
					for(int _repeat10 = 0; _repeat10 < (int)(Double.parseDouble(edittext1.getText().toString())); _repeat10++) {
						a = SketchwareUtil.getRandom((int)(1), (int)(9));
						b = SketchwareUtil.getRandom((int)(1), (int)(9));
						c = SketchwareUtil.getRandom((int)(1), (int)(9));
						e = SketchwareUtil.getRandom((int)(1), (int)(9));
						d = SketchwareUtil.getRandom((int)(1), (int)(9));
						f = SketchwareUtil.getRandom((int)(1), (int)(9));
						g = SketchwareUtil.getRandom((int)(1), (int)(9));
						h = SketchwareUtil.getRandom((int)(1), (int)(9));
						i = SketchwareUtil.getRandom((int)(1), (int)(9));
						j = SketchwareUtil.getRandom((int)(1), (int)(9));
						k = SketchwareUtil.getRandom((int)(1), (int)(9));
						todos = Double.parseDouble(String.valueOf((long)(a)).concat(String.valueOf((long)(b)).concat(String.valueOf((long)(c)).concat(String.valueOf((long)(d)).concat(String.valueOf((long)(e)).concat(String.valueOf((long)(f)).concat(String.valueOf((long)(g)).concat(String.valueOf((long)(j)).concat(String.valueOf((long)(k)))))))))));
						enlaces.add(base.concat(String.valueOf((long)(todos))));
					}
					headers = new HashMap<>();
					headers.put("USER_AGENT", "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.4) Gecko/20100101 Firefox/4.0");
					rm.setHeaders(headers);
					rm.startRequestNetwork(RequestNetworkController.POST, enlaces.get((int)(contador)), "", _rm_request_listener);
				}
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				axd.setAction(Intent.ACTION_VIEW);
				axd.setClass(getApplicationContext(), ZforActivity.class);
				startActivity(axd);
				SketchwareUtil.showMessage(getApplicationContext(), "Reiniciado");
				finish();
			}
		});
		
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", terminados.get((int)(_position))));
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		_rm_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (contador == (enlaces.size() - 1)) {
					SketchwareUtil.showMessage(getApplicationContext(), "Busqueda terminada");
				}
				else {
					textview1.setText(new Gson().toJson(_responseHeaders).replace("Secure\",\"p3p\"", "encontrado"));
					if (new Gson().toJson(_responseHeaders).replace("Secure\",\"p3p\"", "encontrado").equals(new Gson().toJson(_responseHeaders))) {
						contador++;
						rm.startRequestNetwork(RequestNetworkController.POST, enlaces.get((int)(contador)), "", _rm_request_listener);
					}
					else {
						terminados.add(enlaces.get((int)(contador)));
						spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, terminados));
						spinner1.setVisibility(View.VISIBLE);
						contador++;
						rm.startRequestNetwork(RequestNetworkController.POST, enlaces.get((int)(contador)), "", _rm_request_listener);
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_test_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				textview1.setText(new Gson().toJson(_responseHeaders).replace("Secure\",\"p3p\"", "encontrado"));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		spinner1.setVisibility(View.GONE);
		contador = 1;
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}